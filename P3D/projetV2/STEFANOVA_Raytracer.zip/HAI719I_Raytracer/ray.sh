#!/bin/bash
make clean
make
./main