#  M3D - Tp animation 2
## STEFANOVA Albena

J'ai commencé par l'exercice 1 (Animation d'un squelette articulé). Je ne comprenais pas comment faire les coordonnées locales avec les matrices de transformation, ni avec la matrice de rotation. Après avoir passé quelques heures sur cet exercice, j'ai décidé de travailler sur le deuxième exercice. J'ai travaillé sur ma base de code de 28.10. Je n'ai pas réussi à suivre très bien les consignes, mais plus ou moins je me suis amusée à faire la vague.