# Modélisation et géométrie discrète
## TP6 Fonctions de rythme (ou "easing function") et squash-and-stretch
### STEFANOVA Albena 

---


J'ai réussi à implementer le rebond, le mouvement horizontal après la fin de l'animation et l'animation de retour vers le commencement. Toutes les animations s'effectuant en boucle aussi. 

Ce que je n'ai pas réussi a implementer c'est le principe de squash-and-stretch. 