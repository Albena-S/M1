let bdt = {float: 0, int: 1, ushort: 2, ubyte: 3};
